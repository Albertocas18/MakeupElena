<link href="css/animacion.css" rel="stylesheet" type="text/css" />
<iframe src="fondo.php" width="600" height="654"></iframe>

<link href="css/efectos.css" rel="stylesheet" type="text/css">
<link href="css/Neon.css" rel="stylesheet" type="text/css">
<div class="box">
  <div class="inner">
    <div align="left"><span>Ansiedad:(</span>
    </div>
  </div>
  <div class="inner">
    <div align="left"><span>Error 404</span>
    </div>
  </div>
  </div><div class="wrapper">
<a class="button" href="index.php">Regresar</a>
</div>
<div align="center">
  <!-- Filter: https://css-tricks.com/gooey-effect/ -->
</div>
<svg style="visibility: hidden; position: absolute;" width="0" height="0" xmlns="http://www.w3.org/2000/svg" version="1.1">
  <defs>
    <filter id="goo">
      <div align="center">
        <feGaussianBlur in="SourceGraphic" stdDeviation="10" result="blur" />    
        <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="goo" />
        <feComposite in="SourceGraphic" in2="goo" operator="atop"/>
      </div>
    </filter>
  </defs>
</svg>
<iframe src="fondo.php" width="4000" height="654"></iframe>