<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulario de contacto</title>

    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/font-awesome.css">

    <script src="js/jquery-3.2.1.js"></script>
    <script src="js/script.js"></script>
</head>
<body>

    <section class="form_wrap">
        
        <section class="mensaje-exito">
            <h1>SU MENSAJE SE ENVIÓ EXITOSAMENTE</h1>
            <a href="index.html">Enviar nuevo mensaje</a>
        </section>

    </section>

</body>
</html>
