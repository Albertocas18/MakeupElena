<!DOCTYPE html>
<html5>
<head>
    <title>Mi Página web</title>
    <link rel="stylesheet" type="text/css" href="style.css"></li>
</head>
<body>

<div class="row">
   <div id="templatemo_contact" class="col-md-4 gallery-contact">
</div>
   <div class="col-md-8 templatemo_contactform">
   <div class="templatemo_contacttitle">CONTACTO</div>
    <div class="templatemo_sub_contacttitle">Si requieres un subtitulo escribelo aquí</div>
        <p> Escribe aquí el mensaje que quieres presentar si es necesario.</p>

   <form action="enviar.php" method="post">
                        <input type="text" name="name" id="name" class="name" placeholder="NOMBRE">
                        <input type="text" name="mail" id="mail" class="email" placeholder="CORREO">
                        <input type="text" name="phone" id="subject" class="subject" placeholder="TELÉFONO">
                        <textarea name="message" class="message" placeholder="MENSAJE ... " id="message"></textarea>
                        <div class="clear"></div>
                            <div class="col-md-8"> 
                                <button type="submit" class="btn btn-primary">ENVIAR </button>
     </div>
    </form>
    </div>
   <span class="col-md-8">
   <input type="submit" name="boton1" id="boton1" value="REGRESAR">
   </span>

</body>
</html>


<!--En un archivo separado que guardarás con extensión .php y el cual se debe llamar enviar.php, pega el siguiente código:
      
<?php
$name = $_POST['name'];
$mail = $_POST['mail'];
$phone = $_POST['phone'];
$message = $_POST['message'];

$header = 'From: ' . $mail . " \r\n";
$header .= "X-Mailer: PHP/" . phpversion() . " \r\n";
$header .= "Mime-Version: 1.0 \r\n";
$header .= "Content-Type: text/plain";

$message = "Este mensaje fue enviado por: " . $name . " \r\n";
$message .= "Su e-mail es: " . $mail . " \r\n";
$message .= "Teléfono de contacto: " . $phone . " \r\n";
$message .= "Mensaje: " . $_POST['message'] . " \r\n";
$message .= "Enviado el: " . date('d/m/Y', time());

$para = 'josealberto10288@gmail.com';
$asunto = 'Mensaje de PRECOMPC';

mail($para, $asunto, utf8_decode($message), $header);

header("Location:codigo.php");
?>
-->
