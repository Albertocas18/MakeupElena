<!DOCTYPE html>
<html lang="es">
<head>

    <title>Inicio</title>
     <script src="https://www.google.com/recaptcha/api.js"></script>
<style type="text/css">
    body,td,th {
	font-family: FontFamilySPro;
}
    </style>
     <iframe src="./assets/fondo1.php" width="1350" height="400"></iframe>
<?php include './inc/link.php'; ?>

</head>

<body id="container-page-index">
<?php include './inc/navbar.php'; ?>
    <section id="new-prod-index">
         <div class="container">
            <div class="page-header">
                <h1 align="center">Novedades <small>productos</small></h1>
            </div>
            <div class="row">
              <div align="center">
                <?php
                  include 'library/configServer.php';
                  include 'library/consulSQL.php';
                  $consulta= ejecutarSQL::consultar("select * from producto where Stock > 0 limit 6");
                  $totalproductos = mysql_num_rows($consulta);
                  if($totalproductos>0){
                      while($fila=mysql_fetch_array($consulta)){
                         echo '
                        <div class="col-xs-12 col-sm-6 col-md-4">
                             <div class="thumbnail">
                               <img src="assets/img-products/'.$fila['Imagen'].'">
                               <div class="caption">
                                 <h3>'.$fila['Marca'].'</h3>
                                 <p>'.$fila['NombreProd'].'</p>
                                 <p>$'.$fila['Precio'].'</p>
                                 <p class="text-center">
                                 <a href="infoProd.php?CodigoProd='.$fila['CodigoProd'].'" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>&nbsp; Detalles</a>&nbsp;&nbsp;
                                     <button value="'.$fila['CodigoProd'].'" class="btn btn-success btn-sm botonCarrito"><i class="fa fa-shopping-cart"></i>&nbsp; Añadir</button>
                                 </p>

                               </div>
                             </div>
                         </div>     
                         ';
                     }   
                  }else{
                      echo '<h2>No hay productos registrados en la tienda</h2>';
                  }  
              ?>  
              </div>
            </div>
      </div>
</section>
<section id="reg-info-index">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 text-center">
                   <article style="margin-top:20%;">
                        <p align="center"><i class="fa fa-users fa-4x"></i></p>
                        <h3 align="center">Registrate</h3>
                        <p align="center">Registrese y hagase cliente de<br>
                        Makeup Elena para notificar de los nuevos productos.</p>
                        <p align="center"><a href="registration.php" class="btn btn-info btn-block">Registrarse</a></p>   
                     <div align="center"><a href="inc/sistema/index.php"><img src="Imagen.png" width="300" height="35" alt="rec" /></a></div>
                   </article>
                </div>
                
          <div class="col-xs-12 col-sm-6">
                    <div align="center"><img src="assets/img/Cosmetics.jpg" alt="Smart-TV" width="704" height="400" class="img-responsive">
            </div>
          </div>
            </div>
        </div>
        
</section>
    <section id="distribuidores-index">
   <div class="container">
            <div class="col-xs-12 col-sm-6">

            </div>
            <div class="col-xs-12 col-sm-6">

            </div>
     <div class="col-xs-12">
       <div class="page-header">
                  <h1 align="center">Nuestras <small style="color: #333;">Marcas</small></h1>
       </div>
                <div align="center"><br>
                  <br>
                  <img src="assets/img/Logos.png" alt="logos-marcas" width="600" height="468" class="img-responsive">
                </div>
     </div>
      </div>
    </section>
<div align="center"></div>
<div class="rotate"></div>
<?php include './inc/footer.php'; ?>
</body>
</html>