<link href="../css/animacion.css" rel="stylesheet" type="text/css" />
<footer>

    <h3 class="text-center">Siguenos en<br>
  </h3>
  <ul class="list-unstyled text-center">
        <a href="https://www.facebook.com/profile.php?id=100013606205797" title="Facebook" target="new" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom">
            <img src="assets/icons/social-facebook.png" alt="facebook-icon">
        </a>
 <a href="https://www.instagram.com/makeupelemx/" title="Imstagram" target="new" class="social-icon all-elements-tooltip" data-toggle="tooltip" data-placement="bottom">
    <img src="assets/icons/Imagen5.png" alt="Imstagram-icon"></a><br>
    </ul>
  <h5 class="text-center tittles-pages-logo">Makeup Elena &copy; 2020</h5>
  <h4 align="center"><a href="https://makeupelena.000webhostapp.com/">CONTACTAR</a></h4>
</footer>
<link href="css/animacion.css" rel="stylesheet" type="text/css" />
<iframe src="fondo.php" width="1351" height="40"></iframe>
