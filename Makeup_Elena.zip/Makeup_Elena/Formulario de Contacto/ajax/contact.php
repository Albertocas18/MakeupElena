<?php
// comencemos la sesión
session_start();
// obtener los datos del formulario
$admin_email = 'josealberto10288@gmail.com';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$subject = 'Contact Form';
$name = isset($_POST['name']) ? $_POST['name'] : '';
$message = isset($_POST['message']) ? $_POST['message'] : '';
$captcha = isset($_POST['captcha']) ? $_POST['captcha'] : '';
$img_session = isset($_SESSION['img_session']) ? $_SESSION['img_session'] : '';
$website = $_SERVER['SERVER_NAME'];

//comprobar si los campos están vacíos
if(empty($email) or empty($name) or empty($email) or empty($message)){
	$output = "¡Todos los campos son obligatorios!";
}else{
	if(md5($captcha) == $img_session){
$header = "From: $email"."\r\n"
.'Content-Type: text/plain; charset=utf-8'."\r\n";

$message = "
New entry from $subject!

Name: $name
E-Mail: $email
Message:
$message

Este mensaje fue enviado desde http://$website";
		
		if(mail($admin_email, '=?utf-8?B?'.base64_encode($subject).'?=', $message, $header)){
			$output = "¡Tu mensaje fue enviado!<br />¡Gracias!";
		}
	}else{
		$output = "¡Código CAPTCHA erróneo!";
	}
}
echo $output;
?>