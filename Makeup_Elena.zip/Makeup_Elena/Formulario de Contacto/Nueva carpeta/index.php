<!DOCTYPE html>
<?php
	
	if(!empty($_POST)){
		
		$name = $_POST['nombre'];
		$password = $_POST['telefono'];
		$captcha = $_POST['g-recaptcha-response'];
		
		$secret =  '6Ld1kakaAAAAAKNpi5mndL6extrh1qWxn4nkD8Zc';
		
		if(!$captcha){

			echo "Por favor verifica el captcha";
			
			} else {
			
			$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");
			
			$arr = json_decode($response, TRUE);
			
			if($arr['success'])
			{
				echo '<h2>Thanks</h2>';
				} else {
				echo '<h3>Error al comprobar Captcha </h3>';
			}
		}
	}
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulario de contacto</title>
     <script src="https://www.google.com/recaptcha/api.js"></script>

    <link rel="stylesheet" href="css/estilos.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <style type="text/css">
    body,td,th {
	font-family: "Open sans";
}
    </style>
    <script src="js/jquery-3.2.1.js"></script>
    <script src="js/script.js"></script>
</head>
<body bgcolor="#FF33FF">

    <a href="../index.php">REGRESAR</a>
    <section class="form_wrap">

        <section class="cantact_info">
            <section class="info_title">
                <span class="fa fa-user-circle"></span>
                <h2>INFORMACION<br>DE CONTACTO</h2>
            </section>
            <section class="info_items">
                <p><span class="fa fa-envelope"></span> info.contact@gmail.com</p>
                <p><span class="fa fa-mobile"></span> +52(937) 154-0873</p>
            </section>
        </section>

        <form action="enviar.php" method="post" class="form_contact">
            <h2>Envia un mensaje</h2>
            <div class="user_info">
                <label for="names">Nombres *</label>
                <input type="text" id="names" name="nombre" required>

                <label for="phone">Telefono / Celular</label>
                <input type="text" id="phone" name="telefono">

                <label for="email">Correo electronico *</label>
                <input type="text" id="email" name="correo" required>

                <label for="mensaje">Mensaje *</label>
                <textarea id="mensaje" name="mensaje" required></textarea>
                  <div class="g-recaptcha" data-sitekey="6Ld1kakaAAAAAJST53Jkhfrt4NqsIh3x43qqaesf"></div>
			<br>

                <input type="submit" value="Enviar Mensaje" id="btnSend">
            </div>
        </form>

    </section>
    <form name="form1" method="post" action="">
    </form>

</body>
</html>
