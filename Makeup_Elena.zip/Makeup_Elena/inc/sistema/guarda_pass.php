<?php
	
	require 'funcs/conexion.php';
	require 'funcs/funcs.php';
	
	//Aqui va el código PHP del Vídeo
	
?>	