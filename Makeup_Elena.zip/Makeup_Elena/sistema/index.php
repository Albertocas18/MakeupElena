<?php
	
	//Aqui va el código PHP del Vídeo
	
?>
<!doctype html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Login</title>
		
		<link rel="stylesheet" href="css/bootstrap.min.css" >
		<link rel="stylesheet" href="css/bootstrap-theme.min.css" >
		<style type="text/css">
		body {
	background-color: #C3F;
}
        a:link {
	color: #0000CC;
}
        a:visited {
	color: #00C;
}
        a:active {
	color: #F0F0F0;
}
        </style>
		<script src="js/bootstrap.min.js" ></script>
		
	</head>
	
	<body>
		
		<div class="container">    
			<div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
				<div class="panel panel-info" >
					<div class="panel-heading">
						<div class="panel-title">Recuperar Contraseña</div>
						<div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="recupera.php">¿Se te olvid&oacute; tu contraseña?</a></div>
					</div>     
					
					<div style="padding-top:30px" class="panel-body" >
						
						<div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"><span style="border-top: 1px solid#888; padding-top:15px; font-size:85%">No tiene una cuenta! <a href="../../registration.php">Registrate aquí</a></span><span style="border-top: 1px solid#888; padding-top:15px; font-size:85%">No tiene una cuenta! <a href="../../registration.php">Registrate aquí</a> </span>			            </div>
					  <form id="loginform" class="form-horizontal" role="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" autocomplete="off">
					    <span  solid#888; padding-top:15px; font-size:85%">No tiene una cuenta! <a href="../registration.php">Registrate aquí</a></span>
					    <div class="form-group"></div>
		  </form>
			  </div>                     
				</div>  
			</div>
		</div>
	</body>
</html>						