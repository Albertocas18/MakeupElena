<!doctype html>
<!--[if lte IE 9]>
<html lang="en" class="oldie">
<![endif]-->
<!--[if gt IE 9]><!-->
<html lang="en">
<!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Falling Leaves CSS Animation</title>
  
<link href="../css/fondo.css" rel="stylesheet" type="text/css">
</head>
<body>
<!DOCTYPE html>
<html>
    <head>
        <title>
					Octoberfest
			</title>
			<link href="https://fonts.googleapis.com/css?family=Courgette|Open+Sans&display=swap" rel="stylesheet"> 
    </head>
    <body>
        
    <section>
    <h2>
       Bienvenidos a Makeup 
       Elena
      </h2>
  </div>
     <div class="leaf">
     <div>  <img src="img/animacion1.png" height="76" width="76"></img></div>
      <div><img src="img/animacion2.png" height="76" width="76"></img></div>
      <div>  <img src="img/animacion3.png" height="76" width="76"></img></div>
      <div><img src="img/animacion4.png" height="76" width="76"></img></div>
       <div> <img src="img/animacion5.png" height="76" width="76"></img></div>
     <div>   <img src="img/animacion6.png" height="76" width="76"></div>
     <div><img src="img/animacion1.png" height="76" width="76">></div>
            
            
     </div>
     
     <div class="leaf leaf2">
     <div>  <img src="img/animacion1.png" height="76" width="76"></img></div>
      <div><img src="img/animacion2.png" height="76" width="76"></img></div>
      <div>  <img src="img/animacion3.png" height="76" width="76"></img></div>
      <div><img src="img/animacion4.png" height="76" width="76"></img></div>
       <div> <img src="img/animacion5.png" height="76" width="76"></img></div>
       <div><img src="img/animacion6.png" height="76" width="76"></div>
        
			
     </div>
     </section>

    </body>
</html>