1 <?php							
2 $name							
3 $mail							
$_POST['name' ];							
S_POST['mail' ];							
$phone							
							
$		messa					
4							
5      ge							
6							
$_POST['phone'];							
$_POST['messajge ' ;							
]							
$mail							
7 $header							
'From: ·							
""" \r\n"";"							
8 $header							
9 $header							
"""X-Mailer: PHP/"" phpversion() ""Mime-Version: 1.0 \r\n "";"							
"11   \r\n"";"							
-							
10 $header							
11							
"""Content"							
"Type: text/plain"";"							
"$message Smessage
$message
$message
$message"							
$name							
12        ''Este mensaje fue enviado por:							
""" \r\n "";"							
Smail							
13           'Su e-mail es: '							
""" \r\n ';"							
"14          ""Teléfono de contacto: ""  $phone  "" \r\n "";"							
"15           ""Mensaje: ""  $_POST['message'] "" \r\n"";"							
"16          ''Enviado el:·· date ('d/m/Y', time());"							
17							
$para							
					to		
$a			s	un			
com'							
18      'xxxxxxxxxxxxxxx@hotmail.  ;							
19         'Asunto del mensaje';							
20							
$							
a							
$							
$mes							
$							
21 mail(							
22							
"p ra,"							
"asunto, utf8_decode("							
"sage),"							
header);							
"23 header(""Location:index .html"");"							
24    ? >	